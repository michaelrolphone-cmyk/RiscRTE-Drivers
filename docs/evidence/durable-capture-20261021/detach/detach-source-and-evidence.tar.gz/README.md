Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base 1f86a08db75a98247bab47f0f1800c64a4e2075f; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
