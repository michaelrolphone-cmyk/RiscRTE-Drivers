#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
repo="$root/T5S3-Reader"; build="$root/build"; mkdir -p "$build"
for t in protocol session; do
 c++ -std=c++17 -Wall -Wextra -Werror -I"$repo/src" -I"$repo/lib/NativeApps/include" "$repo/test/programmer/esp_rom_${t}_test.cpp" -o "$build/esp-$t"
 "$build/esp-$t"; echo "PASS: historical Reader ESP $t"
done
flags=(-std=c++17 -Wall -Wextra -Werror -I"$repo/test/programmer/stubs" -I"$repo/lib/NativeApps/include" -I"$repo/src")
c++ "${flags[@]}" "$repo/src/native/NativeEspRomBridge.cpp" "$repo/test/programmer/programmer_context_fixture.cpp" "$repo/test/programmer/esp_rom_provider_test.cpp" -o "$build/esp-provider"
"$build/esp-provider"; echo 'PASS: historical Reader ESP provider simulation'
c++ "${flags[@]}" "$repo/src/native/NativeEspRomBridge.cpp" "$repo/test/programmer/esp_rom_context_test.cpp" -o "$build/esp-context"
"$build/esp-context"; echo 'PASS: historical Reader ESP execution-context fixture'
cc -std=c11 -Wall -Wextra -Werror -I"$repo/lib/NativeApps/include" -I"$repo/sdk/driver" "$repo/test/native_apps/firmware_flasher_pagination_test.c" -o "$build/flasher-pagination"
(cd "$repo" && "$build/flasher-pagination"); echo 'PASS: historical Reader firmware selection pagination'
for driver in program_msp usb_msp usb_stlink; do
 bash "$repo/test/run_${driver}_test.sh"
done
repo="$root/RiscRTE-Drivers"
for driver in program_msp usb_msp usb_stlink; do
 cc -std=c11 -Wall -Wextra -Werror -fPIC -fvisibility=hidden -shared -I"$repo/sdk/driver" "$repo/Drivers/$driver/driver.c" -o "$build/current-$driver.so"
 cc -std=c11 -Wall -Wextra -Werror -I"$repo/sdk/driver" "$repo/test/drivers/${driver}_test.c" -ldl -o "$build/current-$driver-test"
 "$build/current-$driver-test" "$build/current-$driver.so"
 echo "PASS: Drivers a7ae399 $driver fixture"
done
