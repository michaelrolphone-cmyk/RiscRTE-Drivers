#!/usr/bin/env python3
"""Offline ABI fixture; supplies fake dependency callbacks and touches no hardware."""
import ctypes as C
import sys

lib = C.CDLL(sys.argv[1])
P = C.c_void_p
U = C.c_uint64
Z = C.c_size_t
B = C.c_bool
U8 = C.c_uint8
I = C.c_int32


class Probe(C.Structure):
    _fields_ = [('device', U), ('vid', C.c_uint16), ('pid', C.c_uint16)] + [
        (n, U8) for n in ('control', 'data', 'rx', 'tx', 'variant', 'jtag', 'sbw', 'uart')]


class Target(C.Structure):
    _fields_ = [('device', U)] + [(n, U8) for n in (
        'variant', 'mode', 'jtag', 'major', 'minor')] + [('reserved', U8 * 2)]


class MSP(C.Structure):
    _fields_ = [('version', C.c_uint32), ('size', C.c_uint32), ('context', P)] + [
        (n, P) for n in ('poll', 'snapshot', 'open', 'set_interface', 'execute', 'close')]


class Dep(C.Structure):
    _fields_ = [('name', C.c_char_p), ('version', C.c_uint32), ('api', P)]


class Driver(C.Structure):
    _fields_ = [('version', C.c_uint32), ('size', C.c_uint32), ('id', C.c_char_p),
                ('capid', C.c_char_p), ('api_version', C.c_uint32), ('cap', P),
                ('start', P), ('stop', P), ('quiesce', P)]


class API(C.Structure):
    _fields_ = [('version', C.c_uint32), ('size', C.c_uint32), ('context', P)] + [
        (n, P) for n in ('open', 'write', 'verify', 'close', 'last_error')]


callbacks = []
live = {}
attempts = {}
closable = set()
next_token = 100
version_fails = True
errors = []


def cb(sig, fn):
    f = sig(fn)
    callbacks.append(f)
    return C.cast(f, P)


def poll(ctx, count):
    return count == 8


def snapshot(ctx, out, count):
    if count[0] < 2:
        count[0] = 2
        return False
    for i in range(2):
        out[i] = Probe(7 + i, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0)
    count[0] = 2
    return True


def open_probe(ctx, device, mode):
    global next_token
    if device in live.values():
        return 0
    next_token += 1
    live[next_token] = device
    attempts[next_token] = 0
    return next_token


def execute(ctx, token, fid, request, n, out, capacity, timeout):
    if token not in live:
        errors.append(('execute-stale', token))
        return -1
    if fid == 0:
        if version_fails:
            return -1
        C.memset(out, 0, 8)
        C.cast(out, C.POINTER(U8))[1] = 200
        return 8
    if fid == 12:
        C.cast(out, C.POINTER(U8))[0] = 0x99
        return 1
    if fid == 0x3a:
        C.memset(out, 0, 8)
        return 8
    if fid in (7, 0x4c, 0x3c):
        return 0
    errors.append(('unexpected-fid', fid))
    return -1


def close_probe(ctx, token):
    if token not in live:
        errors.append(('double-close', token))
        return False
    attempts[token] += 1
    if token not in closable:
        return False
    del live[token]
    return True


msp = MSP(1, C.sizeof(MSP), None,
          cb(C.CFUNCTYPE(B, P, Z), poll),
          cb(C.CFUNCTYPE(B, P, C.POINTER(Probe), C.POINTER(Z)), snapshot),
          cb(C.CFUNCTYPE(U, P, U, U8), open_probe),
          cb(C.CFUNCTYPE(B, P, U, U8), lambda *a: True),
          cb(C.CFUNCTYPE(I, P, U, U8, P, Z, P, Z, C.c_uint32), execute),
          cb(C.CFUNCTYPE(B, P, U), close_probe))
dep = Dep(b'debug.vendor.msp', 1, C.addressof(msp))
lib.t5_driver_get.argtypes = [C.c_uint32]
lib.t5_driver_get.restype = C.POINTER(Driver)
d = lib.t5_driver_get(2).contents
start = C.CFUNCTYPE(B, C.POINTER(Dep), Z)(d.start)
stop = C.CFUNCTYPE(None)(d.stop)
q = C.CFUNCTYPE(B)(d.quiesce)
a = C.cast(d.cap, C.POINTER(API)).contents
open_api = C.CFUNCTYPE(U, P, U, U8, C.POINTER(Target))(a.open)
close_api = C.CFUNCTYPE(B, P, U)(a.close)

assert start(C.byref(dep), 1)
t = Target()
assert open_api(None, 7, 1, C.byref(t)) == 0
assert open_api(None, 8, 1, C.byref(t)) == 0
assert live == {101: 7, 102: 8} and attempts == {101: 1, 102: 1}
assert open_api(None, 7, 1, C.byref(t)) == 0 and next_token == 102
assert not q() and attempts == {101: 2, 102: 2}
stop()
assert not start(C.byref(dep), 1) and attempts == {101: 3, 102: 3}
closable.add(101)
assert not q() and live == {102: 8} and attempts == {101: 4, 102: 4}
assert not q() and attempts == {101: 4, 102: 5}
assert open_api(None, 7, 1, C.byref(t)) == 0 and live == {102: 8, 103: 7}
closable.update((102, 103))
assert q() and not live
frozen = attempts.copy()
assert q()
stop()
assert attempts == frozen
assert start(C.byref(dep), 1)
version_fails = False
public = open_api(None, 7, 1, C.byref(t))
assert public and live == {104: 7}
closable.add(104)
assert close_api(None, public)
assert not close_api(None, public)
stop()
assert start(C.byref(dep), 1)
public2 = open_api(None, 7, 1, C.byref(t))
assert public2 and public2 != public
assert not close_api(None, public) and live == {105: 7}
closable.add(105)
assert close_api(None, public2)
assert q()
stop()
assert not errors, errors
print('Independent unique-transport fixture: PASS (mixed close outcomes, exact retry ownership, '
      'no double close, slot reuse, stop retention, restart stale tokens)')
print('Close-attempt counts:', attempts)
