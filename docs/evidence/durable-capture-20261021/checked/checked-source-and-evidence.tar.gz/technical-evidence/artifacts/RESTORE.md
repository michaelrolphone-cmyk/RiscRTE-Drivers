# USB checked cleanup local candidate

Repository: RiscRTE-Drivers
Branch: tasker/usb-checked-cleanup-20261021
Commit: b4334b76124f80d1252eb7dda9e903fd1b7b4d39
Tree: 42a84c4f24457375ba0dd98e4bf864c4ee398891
Required base: 0dd55680bf565edd8bcb30405d14d2f9b02cd956

The bundle is incremental and requires the base commit. Fetch its
`tasker/usb-checked-cleanup-20261021` branch into a new local branch.
Alternatively, apply the binary patch to a clean base checkout or use git am
with the mbox. SHA256SUMS identifies each archive. The binary patch and bundle
were independently restored and matched the exact tree and commit respectively.

Read docs/USB_CHECKED_CLEANUP_2026-10-21.md in the restored tree for exact source
locks, normal/sanitized evidence, compatibility and remaining limits. This is a
locally qualified software prerequisite, not a target build or delivered native
serial monitor/flasher. No publication, accepted bytes or product pins changed.

Final independent review matched this commit/tree and the reviewed host,
controller and interrupt-header hashes; checked-ack, minimum-size old-controller
and old-header consumer regressions passed on rebuilt committed source.
