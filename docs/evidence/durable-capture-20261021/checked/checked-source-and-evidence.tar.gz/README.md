Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base 0dd55680bf565edd8bcb30405d14d2f9b02cd956; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
