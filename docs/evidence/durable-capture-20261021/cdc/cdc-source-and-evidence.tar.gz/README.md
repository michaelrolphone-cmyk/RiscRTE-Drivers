Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base b4334b76124f80d1252eb7dda9e903fd1b7b4d39; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
