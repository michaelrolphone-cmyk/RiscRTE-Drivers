Original source and technical evidence recovery.

This incremental bundle preserves original commit identities. It requires base a7ae39994603c4545a3c014f09051ecfc12084d2; obtain that source prerequisite before importing. GitHub capture commits have equivalent source trees but distinct metadata.

Tests are scoped historical observations, not firmware release or hardware acceptance. Failed and blocked logs are retained. Build products and private tracker/account/conversation data are excluded.
