#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/RiscRTE-Drivers"
MODE=${1:-plain}
OUT="../evidence/$MODE"
mkdir -p "$OUT"
FLAGS=(-std=c11 -Wall -Wextra -Werror -I sdk/driver -g)
if [[ $MODE == sanitized ]]; then FLAGS+=(-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer); fi
for driver in usb_host_v2 usb_hid usb_hid_keyboard usb_hid_gamepad; do
  cc "${FLAGS[@]}" -fPIC -fvisibility=hidden -shared "Drivers/$driver/driver.c" -o "$OUT/$driver.so"
done
for test in usb_host_v2 usb_hid usb_hid_quiesce; do
  cc "${FLAGS[@]}" "test/drivers/${test}_test.c" -ldl -o "$OUT/$test"
  if [[ $test == usb_host_v2 ]]; then "$OUT/$test" "$OUT/usb_host_v2.so";
  else "$OUT/$test" "$OUT/usb_hid.so" "$OUT/usb_hid_keyboard.so" "$OUT/usb_hid_gamepad.so"; fi
done
for test in usb_hid_keyboard usb_hid_gamepad usb_hid_gamepad_descriptor usb_hid_text_input usb_ui_navigation usb_xinput_gamepad; do
  cc "${FLAGS[@]}" "test/drivers/${test}_test.c" -o "$OUT/$test"
  "$OUT/$test"
done
