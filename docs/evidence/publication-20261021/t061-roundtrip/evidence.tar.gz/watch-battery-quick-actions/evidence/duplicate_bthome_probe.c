#include <stdio.h>
#include "ble_scan_core.h"
int main(void){ble_device d={.seen=123};const uint8_t ad[]={6,0x16,0xd2,0xfc,0x40,1,40,6,0x16,0xd2,0xfc,0x40,1,80};
if(!ble_ad_valid(ad,sizeof(ad)))return 2;ble_ad(&d,ad,sizeof(ad));printf("invalid=%u readings=%u battery=%u value=%u\n",d.measurement_invalid,d.reading_count,d.has_battery,d.battery);return d.measurement_invalid?0:1;}
