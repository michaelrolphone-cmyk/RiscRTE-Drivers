# Draft PR: Qualify BLE telemetry-to-sensor battery interoperability

Repository: michaelrolphone-cmyk/RiscRTE-Drivers
Base: a7ae39994603c4545a3c014f09051ecfc12084d2
Head: tasker/t061-watch-battery at fe310f01a90a616ce05be02b677debdf3cfcd607
Status: local draft only, not pushed or opened

## Summary

- Feed real public telemetry encoder output through the real BLE sensor advertising parser.
- Cover every valid battery percentage, observed peer identity, freshness boundaries, missing/invalid/encrypted readings and multiple battery fields.
- Add the test to the existing normal and sanitizer suite without production changes or package-version changes.

## Why

T061 requests the user's Watch battery in X4 Quick Actions, including its last acquired value and a current-acquisition indicator. The shared wire path is reusable, but current Quick Actions is local-battery-only. This regression test establishes what the current public broadcast can and cannot supply before integrating a peer-selection/acquisition contract.

## Checks

- Six driver suites pass normally.
- Six driver suites pass with ASan/UBSan and leak detection disabled for the ptrace-hosted executor.
- Unchanged System Apps Quick Actions passes 108 core/session/adapter executions normally and with sanitizers/rotations as selected by its runner.
- git diff --check passes.

## Boundaries

This test-only PR does not implement T061, choose a Watch, start a scan, persist an identifier, pair, change privacy/security, or modify Quick Actions presentation. It must not close T061. No target/product build or hardware qualification occurred. Existing accepted firmware and source pins are untouched. Publication remains held and is not covered by the pending Spectrum/T039 approval request.
