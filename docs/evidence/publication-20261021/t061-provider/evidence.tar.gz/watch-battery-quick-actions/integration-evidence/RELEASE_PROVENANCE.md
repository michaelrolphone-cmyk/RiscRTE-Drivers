# Existing release provenance, not a T061 delivery

Latest published X4 release inspected: [test-native-provision-0.1.123](https://github.com/michaelrolphone-cmyk/RiscRTE-XTEINK-X4-PRO/releases/tag/test-native-provision-0.1.123), published 2026-10-16 23:00:36 UTC. The tag resolves directly to producer commit `93ee386b7e23628f3776edc6cfd2805cf675d649`. The release reports immutable=false: use commit IDs and asset hashes rather than the mutable release URL alone.

The release's System pin `0651a55513b0aa0dff1b6a9072303def08a97378` still renders the local X4 battery only. It is not current System main `7270a10ed9cefba6ec1368060196a13bb3370985`. X4 current main `6b7d1abe9b2dcc236f6086d07c0f619244c907cb` is also not the compiled release.

## Exact .123 source set

- Product: `93ee386b7e23628f3776edc6cfd2805cf675d649`; tree `014a47e12262db66137223c901dab337b0c2a0ad`.
- System: `0651a55513b0aa0dff1b6a9072303def08a97378`; tree `8cbe597072c60d6d8a54d852e953b9ee876db12e`.
- Runtime: `6a3b3d46f5b2857eacc6e9863799dec1f466b036`; tree `a5cc849726698c8651aa503af788b938bca28ec2`.
- Drivers: `5890721073ebabd781d5d278e447c761947a5c58`; tree `884416cb8ec2f95edcfc945a4a996f3dbca317c6`.
- Utilities: `e80172353fcb9e6519ca9d9b2a4d43c69c1bc91d`; tree `39a1fdef3719dddbd9ebfd9fb3750e15c856223c`.
- Reader: `c98e4222048244b1e729869ed47aa99130025fd3`; tree `a5ee3231bf2de0cea3d484765cd5aa639721a4a8`.
- Image helper/T-Watch: `74f7491dc470b92dfa41fce41bf0c500f3714a94`; tree `e1418b6940d8b8df6b6a82057968b5074a96f2c6`.
- ESP-IDF 6.1: `fff9895c82d744c7237be8847347bdd1b07c6643`; tree `e6a5e4865e2027f1f0cef5da09f254d65c5cec22`.
- Separate archive qualifier: `6ff97dac5f119307a0ae63db5d2e11d09ea49516`; tree `9069500a47add2b73b79d2e3359e25905e2403c0`.

The source contract is copied beside this report as `x4-123-contract.json`. Shared code is referenced, not vendored or changed.

## Retained receiver

The .123 update rebuilds Home/catalog only; it retains the BLE sensor binary rather than rebuilding it from the newer Drivers input pin. The historical .055 executable plan records receiver Drivers source `4088b6892c2e2654b0342f04a7d191068e4a8e2e`, tree `1c59a23db93d88ea11a2bc4964004df3505dc7d7`. Its `driver.c`, `ble_scan_core.h` and manifest are byte-identical at the .123 Drivers input pin.

- Retained `sensors/driver.elf` SHA-256: `cf34fa23f8a6086c7dbeb022a5ddc252088207eb0773251d183873bf1737d998`.
- Retained manifest SHA-256: `e1cbdd0a2490a88cd8984404e37b6ef059403d31f87f47be9c7756fb0133b0b5`.

## Public asset identity

- [source-lock.json](https://github.com/michaelrolphone-cmyk/RiscRTE-XTEINK-X4-PRO/releases/download/test-native-provision-0.1.123/source-lock.json): SHA-256 `a8b57f94990d1fabd83c0151f4c737cc1ec26ae647ae5789c9f3ffa5d99880ea`.
- [qualification.json](https://github.com/michaelrolphone-cmyk/RiscRTE-XTEINK-X4-PRO/releases/download/test-native-provision-0.1.123/qualification.json): SHA-256 `f3b3ab8b706de517ef1c1358a732c8ec258833f5a96684681991d67a92698331`.
- Firmware: 1,804,976 bytes; SHA-256 `cf8e376ebf1f92142d2ff8bdf8bbabfea2579cd8598548202b64728065da4a13`.
- Factory: 16,777,216 bytes; SHA-256 `85d197fb4ea6f1bdf2f02705b701c7e6667362a20cb856672c46b49fd51265b0`.
- Complete SD package remains unchanged .121: SHA-256 `2b6dce3efb468f3cd728b50707e0c9552d84e225b65e2b27e683d3d726bc6cef`.

Existing standalone sender components were previously reconciled under T043:
- [ble-telemetry 0.1.0](https://github.com/michaelrolphone-cmyk/RiscRTE-T-Watch-S3/releases/tag/driver-ble-telemetry-v0.1.0): 66,832 bytes; SHA-256 `8cece7a6e8f3dbe8ec2ef9a0f0dfbd919c147152c695143730d04cb10c80a5b1`.
- [telemetry-battery 0.1.0](https://github.com/michaelrolphone-cmyk/RiscRTE-T-Watch-S3/releases/tag/driver-telemetry-battery-v0.1.0): 61,634 bytes; SHA-256 `8859f855a59ba92709840b003a8121e91d69f1badfd8b738a6dae35bf44b3f3d`.

None of these releases proves Quick Actions remote-battery integration.

## Qualification limits

The .123 release is software-qualified, not hardware-qualified. Its producer's preserving-transition qualification failed; a separate successful run qualified the unchanged archive. Factory bootstrap self-admission passes, but the .122-to-.123 preserving transition remains rejected. Factory flashing erases internal data; there is no preserving/OTA kit. Boot, health confirmation, rollback and physical BLE behavior remain unqualified. No flashing or publication was performed for this investigation, and the frozen accepted version/payload gates were not altered.
