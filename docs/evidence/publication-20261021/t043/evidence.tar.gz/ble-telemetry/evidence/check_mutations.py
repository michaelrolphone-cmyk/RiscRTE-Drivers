#!/usr/bin/env python3
"""Run temporary capability-custody mutants; never modify the checkout."""
import pathlib, shutil, subprocess, tempfile, json, sys
root=pathlib.Path(__file__).resolve().parents[1]/'RiscRTE-Drivers'
original=(root/'Drivers/ble_telemetry/driver.c').read_text()
mutations={
 'enumeration_context_dropped':('source->enumerate(source->context,','source->enumerate(NULL,'),
 'read_context_dropped':('source->read(source->context,','source->read(NULL,'),
 'unselected_battery_sampled':('static bool sample(void){','static bool sample(void){\n int32_t ignored; (void)source->read(source->context,7,&ignored);')}
results=[]
for name,(old,new) in mutations.items():
 with tempfile.TemporaryDirectory(prefix='t043-mutation-') as temp:
  d=pathlib.Path(temp)
  for folder in ['Drivers/ble_telemetry','sdk/driver','test']:
   shutil.copytree(root/folder,d/folder)
  (d/'Drivers/ble_telemetry/driver.c').write_text(original.replace(old,new))
  if '--baseline' in sys.argv:
   baseline=subprocess.check_output(['git','show','a7ae39994603c4545a3c014f09051ecfc12084d2:test/ble_telemetry_test.c'],cwd=root,text=True)
   (d/'test/ble_telemetry_test.c').write_text(baseline)
  build=subprocess.run(['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-I'+str(d/'sdk/driver'),str(d/'test/ble_telemetry_test.c'),'-o',str(d/'fixture')],capture_output=True,text=True)
  if build.returncode: raise RuntimeError(build.stderr)
  run=subprocess.run([str(d/'fixture')],capture_output=True,text=True)
  results.append({'mutation':name,'exit_code':run.returncode,'survived':run.returncode==0,'stdout':run.stdout,'stderr':run.stderr.replace(str(d),'<temporary-checkout>')})
print(json.dumps(results,indent=2))
if sys.argv[1:] and sys.argv[1]=='require-killed':
 sys.exit(any(r['survived'] for r in results))
